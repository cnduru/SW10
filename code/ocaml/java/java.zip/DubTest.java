public class DubTest{
    public static void main(String[] args) {
        if (args.length > 1){
            System.out.print("Hello World!");
        }
    }
}
